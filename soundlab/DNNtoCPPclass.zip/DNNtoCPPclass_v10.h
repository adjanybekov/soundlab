#pragma once
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <dirent.h>

class DNNtoCPPclass
{
private:
	int CoL = 0;
	int RoL = 0;
	int LN = 0;
	struct parameters {
		double* W = NULL;
		double* b = NULL;
		int sRol = 0;
		int sCol = 0;
	};
	parameters* myParameters = NULL;// new parameters[4];

	double* linear_forward(double A_previous[], int L);
	double* relU(double * Z, int L);
	double* sigmoid(double * Z, int L);
public:
	//DNNtoCPPclass();
	void LoadParameters(char* Dir);
	void getParameters(int ParIndex,int k);
	
	double predict(double* A_input);

	friend void CSV_reader(std::string csvfile, parameters* pparameters);
	friend void CSV_Breader(std::string csvfile, parameters* pparameters);	
	//friend double* linear_forward(double A_previous[], int CL, int PL, DNNtoCPPclass::parameters* pparameters, int LN);
	 
};
